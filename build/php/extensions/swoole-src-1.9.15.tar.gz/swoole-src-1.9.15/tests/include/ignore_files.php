<?php
$ignore_files = [
    __DIR__ . "/swoole_async/big_zero",
    __DIR__ . "/swoole_async/big_zero.copy",
    __DIR__ . "/swoole_client_async/test.jpg",
    __DIR__ . "/swoole_process/echo.py",
];

return $ignore_files;